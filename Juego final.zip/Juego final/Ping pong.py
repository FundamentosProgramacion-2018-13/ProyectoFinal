
# Autor: Zabdiel Valentín Garduño Vivanco
# Videojuego de python utilizado la libreria pygame. Juego: Ping pong

import pygame   # Librería de pygame
from pygame.locals import *

from random import randint


# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600
# Colores
BLANCO = (255, 255, 255)  # R,G,B en el rango [0,255], 0 ausencia de color, 255 toda la intensidad
VERDE_BANDERA = (27, 94, 32)    # un poco de rojo, más de verde, un poco de azul
ROJO = (255, 0, 0)      # solo rojo, nada de verde, nada de azul
AZUL = (0, 0, 255)      # nada de rojo, ni verde, solo azul
NEGRO=(0,0,0)
#Estados
MENU=1#Menu principal
MENU02=3#Menu de seleccion de control
JUGANDO=2#
MODO=None

# Estructura básica de un programa que usa pygame para dibujar
def dibujarPala(ventana, spritePala):
    ventana.blit(spritePala.image, spritePala.rect)

def dibujarPala02(ventana, spritePala02):
    ventana.blit(spritePala02.image, spritePala02.rect)


def dibujarPelota(ventana, spritePelota):
    ventana.blit(spritePelota.image, spritePelota.rect)

def actualizarPelota(pelota,tiempo,pala,pala02,puntos,efecto):
    pelota.rect.centerx += pelota.speed[0] * tiempo
    pelota.rect.centery += pelota.speed[1] * tiempo

    if pelota.rect.left <= 0:
        puntos[1] += 1       #Se crea una lista donde puntos[0] son los del jugador

    if pelota.rect.right >= ANCHO:
        puntos[0] += 1       #Se crea una lista donde puntos[1] son los del CPU


    if pelota.rect.left <= 0 or pelota.rect.right >= ANCHO:
        pelota.speed[0] = -pelota.speed[0]
        pelota.rect.centerx += pelota.speed[0] * tiempo
    if pelota.rect.top <= 0 or pelota.rect.bottom >= ALTO:
        pelota.speed[1] = -pelota.speed[1]
        pelota.rect.centery += pelota.speed[1] * tiempo
    if pygame.sprite.collide_rect(pelota,pala):
        efecto.play()
        pelota.speed[0]=-pelota.speed[0]
        pelota.rect.centerx += pelota.speed[0] * tiempo
    if pygame.sprite.collide_rect(pelota,pala02):
        efecto.play()
        pelota.speed[0] = -pelota.speed[0]
        pelota.rect.centerx += pelota.speed[0] * tiempo

    return puntos

def mover(pala,tiempo,keys):#Movimiento de 1 jugador Teclado

    if pala.rect.top>=0:
        
        if keys[K_w]:
            pala.rect.centery -= pala.speed*tiempo

    if pala.rect.bottom <= ALTO:
        
        if keys[K_s]:
            pala.rect.centery += pala.speed * tiempo

def mover03(pala):#Movimiento con Mouse
    if pala.rect.top>=0 or pala.rect.bottom<=ALTO:
        xm,ym=pygame.mouse.get_pos()
        pala.rect.top=ym
        pala.rect.bottom=ym

def ia(pala02,tiempo,pelota):#Inteligencia artificial basica
    if pelota.speed[0] >= 0 and pelota.rect.centerx >= ANCHO/2:
        if pala02.rect.centery < pelota.rect.centery:
            pala02.rect.centery += pala02.speed * tiempo
        if pala02.rect.centery > pelota.rect.centery:
            pala02.rect.centery -= pala02.speed * tiempo

def mover02(pala02,tiempo,keys):#Movimeinto jugador 2
    if pala02.rect.top>=0:
        if keys[K_UP]:
            pala02.rect.centery -= pala02.speed*tiempo
    if pala02.rect.bottom <= ALTO:
        if keys[K_DOWN]:
            pala02.rect.centery += pala02.speed * tiempo





def texto(texto,posx,posy,color=(255,255,255)):
    fuente=pygame.font.Font("DroidSans.ttf",25)
    salida=pygame.font.Font.render(fuente,texto,1,color)
    salida_rect = salida.get_rect()
    salida_rect.centerx = posx
    salida_rect.centery = posy
    return salida,salida_rect

def actualizarDatosJugador(ventana,texto,posicion):
    ventana.blit(texto,posicion)

def actualizarDatosCPU(ventana,texto,posicion):
    ventana.blit(texto,posicion)


def dibujar():
    # Inicializa el motor de pygame
    pygame.init()
    # Crea una ventana de ANCHO x ALTO
    ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana donde dibujará
    pygame.display.set_caption("Prueba")
    fondo=pygame.image.load("fondo.jpg")
    puntos=[0,0]
    reloj = pygame.time.Clock()  # Para limitar los fps
    termina = False  # Bandera para saber si termina la ejecución, iniciamos suponiendo que no


    #Pelota
    pelota=pygame.image.load("pelota.png")
    spritePelota=pygame.sprite.Sprite()
    spritePelota.image=pelota
    spritePelota.rect=pelota.get_rect()
    spritePelota.rect.centerx=ANCHO/2
    spritePelota.rect.centery=ALTO/2
    spritePelota.speed=[0.58,-0.58]#0.5,-0.5


    #Pala

    pala=pygame.image.load("pala.png")
    spritePala=pygame.sprite.Sprite()
    spritePala.image=pala
    spritePala.rect=pala.get_rect()
    spritePala.rect.centerx=50#30
    spritePala.rect.centery=ALTO/2
    spritePala.speed=0.5

    #Pala_CPU. Una pala que se mueve por inteligencia artificial basica
    pala02=pygame.image.load("pala.png")
    spritePala02=pygame.sprite.Sprite()
    spritePala02.image=pala02
    spritePala02.rect=pala.get_rect()
    spritePala02.rect.centerx=ANCHO-50
    spritePala02.rect.centery=ALTO/2
    spritePala02.speed=0.5

    #Estado del Menu
    estado=MENU
    #Imagenes para el Menu
    botonUnjugador=pygame.image.load('Unjugador.png')
    botonDosJugadores=pygame.image.load('dosJugadores.png')
    botonMouse=pygame.image.load('mouse.png')
    botonTeclado=pygame.image.load('teclado.png')
    instrucciones=pygame.image.load("I.png")
    instrucciones02=pygame.image.load("I2.png")
    titulo=pygame.image.load("Titulo.png")
    #Audio
    pygame.mixer.init()
    efecto=pygame.mixer.Sound("ejemplo.wav")
    pygame.mixer.music.load("Fondo.mp3")
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(0.3)
    #Texto del juego
    fuente02=pygame.font.Font("DroidSans.ttf",25)

    while not termina:  # Ciclo principal, MIENTRAS la variable termina sea False, el ciclo se repite automáticamente
        # Procesa los eventos que recibe
        tiempo=reloj.tick(60)  # 40 fps
        keys=pygame.key.get_pressed()
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True      # Queremos terminar el ciclo

            elif evento.type==pygame.MOUSEBUTTONDOWN and estado==MENU:#Menu principal a la seccion un jugador
                xm,ym=pygame.mouse.get_pos()
                xb=ANCHO//2-128
                yb=ALTO//2-50
                anchoB=256
                altoB=100
                if xm>=xb and xm<=xb+anchoB and ym>=yb and ym<=yb+altoB:
                    estado=MENU02
                xa=ANCHO//2-128
                ya=450-50
                if xm>=xa and xm<=xa+anchoB and ym>=ya and ym<=ya+altoB:
                    estado=JUGANDO
                    MODO=2
                    spritePelota.rect.centerx=ANCHO/2
                    spritePelota.rect.centery=ALTO/2
                    puntos=[0,0]
            elif evento.type==pygame.MOUSEBUTTONDOWN and estado==MENU02:
                xm,ym=pygame.mouse.get_pos()
                xb=ANCHO//2-128
                yb=ALTO//4-50
                anchoB=256
                altoB=100
                if xm>=xb and xm<=xb+anchoB and ym>=yb and ym<=yb+altoB:
                    estado=JUGANDO
                    MODO=1
                    spritePelota.rect.centerx=ANCHO/2
                    spritePelota.rect.centery=ALTO/2
                    puntos=[0,0]
                xa=ANCHO//2-128
                ya=ALTO//2-50
                if xm>=xa and xm<=xa+anchoB and ym>=ya and ym<=ya+altoB:
                    estado=JUGANDO
                    MODO=3
                    spritePelota.rect.centerx=ANCHO/2
                    spritePelota.rect.centery=ALTO/2
                    puntos=[0,0]

        if estado==MENU:
            #Borrar pantalla
            ventana.blit(fondo,(0,0))
            ventana.blit(botonUnjugador,(ANCHO//2-128,ALTO//2-50))
            ventana.blit(botonDosJugadores,(ANCHO//2-128,450-50))
            texto03=fuente02.render("Creditos: Zabdiel Valentín Garduño Vivanco",1,BLANCO)
            texto04=fuente02.render("Esc: Salir del juego",1,BLANCO)
            ventana.blit(instrucciones02,(550,300))
            ventana.blit(texto03,(80,480))
            ventana.blit(texto04,(80,510))
            ventana.blit(instrucciones,(20,300))
            ventana.blit(titulo,(ANCHO//2-175,30))

        if estado==MENU02:
            ventana.blit(fondo,(0,0))
            ventana.blit(botonTeclado,(ANCHO//2-128,ALTO//4-50))
            ventana.blit(botonMouse,(ANCHO//2-128,ALTO//2-50))
            ventana.blit(instrucciones,(ANCHO//2-128,450))


        elif estado==JUGANDO:

            #Actualizar objetos
            actualizarPelota(spritePelota,tiempo,spritePala,spritePala02,puntos,efecto)
            if MODO==1:

                mover(spritePala,tiempo,keys)
                #mover03(spritePala)
                ia(spritePala02,tiempo,spritePelota)
                #mover02(spritePala02,tiempo,keys)
            if MODO==2:
                mover(spritePala,tiempo,keys)
                mover02(spritePala02,tiempo,keys)
            if MODO==3:
                mover03(spritePala)
                ia(spritePala02,tiempo,spritePelota)
            textoJugador,posicionTexto01=texto(str(puntos[0]),ANCHO/4, 40)


            textoCPU, posicionTexto02 = texto(str(puntos[1]), ANCHO-ANCHO/4, 40)


            ventana.blit(fondo,(0,0))#Colocamos el fondo en medio
            # Dibujar, aquí haces todos los trazos que requieras
            texto05=fuente02.render("Space: Salir al menu principal",1,BLANCO)
            ventana.blit(texto05,(220,ALTO-100))

            dibujarPelota(ventana,spritePelota)
            dibujarPala(ventana,spritePala)
            dibujarPala02(ventana,spritePala02)
            #ventana.blit(x,y)
            actualizarDatosJugador(ventana,textoJugador,posicionTexto01)
            actualizarDatosCPU(ventana,textoCPU,posicionTexto02)
            #objeto(tiempo,keys)
            if keys[K_SPACE]:
                estado=MENU




            # Cargar una imagen como fondo

        pygame.display.flip()
        if keys[K_ESCAPE]and estado==MENU:
            termina=True
    # Después del ciclo principal
    pygame.quit()#termina pygame


# Función principal, aquí resuelves el problema
def main():
    dibujar()   # Por ahora, solo dibuja


# Llamas a la función principal
main()
