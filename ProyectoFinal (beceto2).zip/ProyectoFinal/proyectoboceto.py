def dibujarBalas2(ventana, listaBalas2):
    for bala in listaBalas2:
        ventana.blit(bala.image, bala.rect)

def moverBlalas2(listaBalas2):
    for bala in listaBalas2:
        if (randint(0,100) < bala.rangoDisparo):
            bala.rangoDisparo -= 5

dibujarBalas2(ventana, listaBalas2)