import pygame
from random import randint
import math

# Dimensiones de la pantalla
ANCHO = 640
ALTO = 480
# # Colores
BLANCO = (255, 255, 255)  # R,G,B en el rango [0,255], 0 ausencia de color, 255 toda la intensidad
VERDE_BANDERA = (27, 94, 32)    # un poco de rojo, más de verde, un poco de azul
ROJO = (255, 0, 0)      # solo rojo, nada de verde, nada de azul
AZUL = (0, 0, 255)      # nada de rojo, ni verde, solo azul
NEGRO = (0, 0, 0)

#Estado
MENU = 1
JUGANDO = 2

# Estructura básica de un programa que usa pygame para dibujar
def dibujarPersonaje(ventana, spritePersonaje):
    ventana.blit(spritePersonaje.image, spritePersonaje.rect)


def dibujarEnemigos(ventana, listaEnemigos):
    for enemigo in listaEnemigos:
        ventana.blit(enemigo.image, enemigo.rect)

def moverEnemigos(listaEnemigos, alfa):
    for enemigos in listaEnemigos:
        enemigos.rect.bottom += 1
        dx = 2*math.cos(math.radians(alfa))
        enemigos.rect.left += dx
        """if enemigos.descenso == enemigos.rect.top:
            enemigos.contador = 0
            enemigos.descenso = enemigos.top+ 100"""


def dibujarBalas(ventana, listaBalas):
    for bala in listaBalas:
        ventana.blit(bala.image, bala.rect)


def moverBalas(listaBalas):
    for bala in listaBalas:
        bala.rect.bottom -= 20



def dibujarMenu(ventana, imgBtnJugar):
    ventana.blit(imgBtnJugar, (ANCHO//2-128, ALTO//3))


def verificarColision(listaEnemigos, listaBalas):
    for bala in listaBalas:
        for enemigo in listaEnemigos:   #Recorrer con INDICES
            #bala vs enemigo
            xb = bala.rect.left
            yb = bala.rect.bottom
            xe = enemigo.rect.left
            ye = enemigo.rect.bottom
            anchoE = enemigo.rect.width
            anchoB = bala.rect.width
            altoB= bala.rect.height
            altoE = enemigo.rect.height
            if (xe<=xb+10<=xe+anchoE or xe<=xb+anchoB-10<=xe+anchoE) and ye<=yb<= ye+altoE:
                #Golpeo al enemigo
                listaEnemigos.remove(enemigo)
                break


def dibujar():
    # Inicializa el motor de pygame
    pygame.init()
    # Crea una ventana de ANCHO x ALTO
    ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana donde dibujará
    reloj = pygame.time.Clock()  # Para limitar los fps
    termina = False  # Bandera para saber si termina la ejecución, iniciamos suponiendo que no

    imgPersonaje = pygame.image.load("pytanque1.png")
    spritePersonaje = pygame.sprite.Sprite()
    spritePersonaje.image = imgPersonaje
    spritePersonaje.rect = imgPersonaje.get_rect()
    spritePersonaje.rect.left = ANCHO//2
    spritePersonaje.rect.bottom = ALTO

    listaEnemigos = []
    imgEnemigo = pygame.image.load("pynave1.png")
    for k in range(50):
        spriteEnemigo = pygame.sprite.Sprite()
        spriteEnemigo.image = imgEnemigo
        spriteEnemigo.rect = imgEnemigo.get_rect()
        spriteEnemigo.rect.left = randint(0, ANCHO-spriteEnemigo.rect.width) + ANCHO
        spriteEnemigo.rect.bottom = randint(0, ALTO)
        listaEnemigos.append(spriteEnemigo)






        listaBalas = []
        imgBala = pygame.image.load("pybala1.png")

        listaBalas2 = []
        imgBala2 = pygame.image.load("pybala2.png")


        estado = MENU

        #Menú
        imgBtnJugar = pygame.image.load("button_jugar.png")

        #Fondo
        imgFondo = pygame.image.load("tierra.jpg")

        # Tiempo
        timer = 0 # Acumulador de tiempo

        # Texto
        fuente = pygame.font.SysFont("monospace", 64)

        # Audio
        #pygame.mixer.init()
        #pygame.mixer.music.load("shoot.wav")
        #pygame.mixer.music.play(-1)

        #efecto = pygame.mixer.Sound("shoot.wav")

        angulo = 0

    while not termina:  # Ciclo principal, MIENTRAS la variable termina sea False, el ciclo se repite automáticamente
        # Procesa los eventos que recibe
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True      # Queremos terminar el ciclo
            elif evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_RIGHT:
                    spritePersonaje.rect.left += 30
                elif evento.key == pygame.K_LEFT:
                    spritePersonaje.rect.left -= 30
                elif evento.key == pygame.K_z:
                    spriteBala = pygame.sprite.Sprite()
                    spriteBala.image = imgBala
                    spriteBala.rect = imgBala.get_rect()
                    spriteBala.rect.left = spritePersonaje.rect.left + spritePersonaje.rect.width//2-spriteBala.rect.width//2
                    spriteBala.rect.bottom = spritePersonaje.rect.bottom-spritePersonaje.rect.width
                    listaBalas.append(spriteBala)
                    print(len(listaBalas))

            elif evento.type == pygame.MOUSEBUTTONUP:
                xm, ym = pygame.mouse.get_pos() #valores de dubla
                print(xm, ", ", ym)
                xb = ANCHO//2-128
                yb = ALTO//3
                if xm > xb and xm <= xb + 256 and ym >= yb and ym <= yb + 100:
                    estado = JUGANDO





        # Borrar pantalla
        ventana.fill(NEGRO)

        if estado == JUGANDO:
            #Tiempo
            if timer >= 2:
                timer = 0
                # Crear una bala
                #efecto.play()
                ''''
                spriteBala = pygame.sprite.Sprite()
                spriteBala.image = imgBala
                spriteBala.rect = imgBala.get_rect()
                spriteBala.rect.left = spritePersonaje.rect.left + spritePersonaje.rect.width
                spriteBala.rect.bottom = spritePersonaje.rect.bottom
                listaBalas.append(spriteBala)
                '''
                # ENEMIGOS
                spriteEnemigo = pygame.sprite.Sprite()
                spriteEnemigo.image = imgEnemigo
                spriteEnemigo.rect = imgEnemigo.get_rect()
                spriteEnemigo.rect.left = randint(0, ANCHO)
                spriteEnemigo.rect.bottom = randint(0, ALTO//2)-ALTO//2
                listaEnemigos.append(spriteEnemigo)

            #Actualizar enemigos
            moverEnemigos(listaEnemigos, angulo)
            angulo = (angulo + 1) % 360
            moverBalas(listaBalas)
            verificarColision(listaEnemigos, listaBalas)

            # Dibujar, aquí haces todos los trazos que requieras
            # Normalmente llamas a otra función y le pasas -ventana- como parámetro, por ejemplo, dibujarLineas(ventana)
            # Consulta https://www.pygame.org/docs/ref/draw.html para ver lo que puede hacer draw
            ventana.blit(imgFondo, (0, 0))
            dibujarPersonaje(ventana, spritePersonaje)
            dibujarEnemigos(ventana, listaEnemigos)
            dibujarBalas(ventana, listaBalas)

        elif estado == MENU:
            #Dinujar menú
            dibujarMenu(ventana, imgBtnJugar)

            #Texto de la pantalla
            #texto = fuente.render("Valor de imgFondo %d" % imgFondo, 1, ROJO)
            #ventana.blit(texto, (ANCHO // 2 - 400, 50))

        pygame.display.flip()  # Actualiza trazos (Si no llamas a esta función, no se dibuja)
        reloj.tick(40)  # 40 fps
        timer += 1/40

    # Después del ciclo principal
    pygame.quit()  # termina pygame


# Función principal, aquí resuelves el problema
def main():
    dibujar()   # Por ahora, solo dibuja








# Llamas a la función principal
main()