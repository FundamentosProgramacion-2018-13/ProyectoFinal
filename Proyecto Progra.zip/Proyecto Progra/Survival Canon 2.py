#Alberto Contreras Torres
#Survival Canon

import pygame   # Librería de pygame
from random import randint

# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600
# Colores
BLANCO = (255, 255, 255)  # R,G,B en el rango [0,255], 0 ausencia de color, 255 toda la intensidad
VERDE = (51, 255, 51)    # un poco de rojo, más de verde, un poco de azul
ROJO = (255, 0, 0)      # solo rojo, nada de verde, nada de azul
AZUL = (0, 0, 255)      # nada de rojo, ni verde, solo azul
NEGRO = (0,0,0)

#Estados
MENU = 1
JUGANDO = 2

#Estados de movimiento
QUIETO = 1
ABAJO = 2
ARRIBA = 3


def dibujarPersonaje(ventana, spritePersonaje):
    ventana.blit(spritePersonaje.image, spritePersonaje.rect)
# Estructura básica de un programa que usa pygame para dibujar
def dibujarEnemigos(ventana, listaEnemigos):
    #Visitar a cada elemento
    for enemigo in listaEnemigos:
        ventana.blit(enemigo.image, enemigo.rect)

def dibujarEnemigosA(ventana, listaEnemigosA):
    for enemigo in listaEnemigosA:
        ventana.blit(enemigo.image, enemigo.rect)

def dibujarEnemigosArriba(ventana, listaEnemigosArriba):
    for enemigo in listaEnemigosArriba:
        ventana.blit(enemigo.image, enemigo.rect)

def dibujarEnemigosIzquierda(ventana, listaEnemigosIzquierda):
    for enemigo in listaEnemigosIzquierda:
        ventana.blit(enemigo.image, enemigo.rect)


def moverEnemigos(listaEnemigos):
    for enemigo in listaEnemigos:
        enemigo.rect.left -= 1

def moverEnemigosIzquierda(listaEnemigosIzquierda):
    for enemigo in listaEnemigosIzquierda:
        enemigo.rect.left += 1
        #enemigo.rect.bottom += 1


def moverEnemigosA(listaEnemigosA):
    for enemigo in listaEnemigosA:
        enemigo.rect.bottom -= 1

def moverEnemigosArriba(listaEnemigosArriba):
    for enemigo in listaEnemigosArriba:
        enemigo.rect.bottom += 1

#-----------------------------------------------------------------------------------------------------------------------------------------BALAS-----------------------------------------------
def dibujarBalas(ventana, listaBalas):
    for bala in listaBalas:
        ventana.blit(bala.image, bala.rect)

def dibujarBalasIzquierda(ventana, listaBalasIzquierda):
    for bala in listaBalasIzquierda:
        ventana.blit(bala.image, bala.rect)

def dibujarBalasAbajo(ventana, listaBalasAbajo):
    for bala in listaBalasAbajo:
        ventana.blit(bala.image, bala.rect)

def dibujarBalasArriba(ventana, listaBalasArriba):
    for bala in listaBalasArriba:
        ventana.blit(bala.image, bala.rect)


def moverBalas(listaBalas):
    for bala in listaBalas:
        bala.rect.left += 2

def moverBalasIzquierda(listaBalasIzquierda):
    for bala in listaBalasIzquierda:
        bala.rect.left -= 2

def moverBalasAbajo(listaBalasAbajo):
    for bala in listaBalasAbajo:
        bala.rect.bottom += 2

def moverBalasArriba(listaBalasArriba):
    for bala in listaBalasArriba:
        bala.rect.bottom -= 2

def dibujarMenu(ventana, imgBtnJugar):
    ventana.blit(imgBtnJugar, (ANCHO//2-128, ALTO//3))


def verificarColision(listaEnemigos, listaBalas):
    for k in range (len(listaBalas)-1,-1,-1):
        bala=listaBalas[k]
        for e in range (len(listaEnemigos)-1,-1,-1):  #Recorrer con Indices
            enemigo = listaEnemigos[e]
            #bala VS enemigo
            xb = bala.rect.left
            yb = bala.rect.bottom
            xe, ye, ae, alte = enemigo.rect
            if xb >= xe and xb <= xe + ae and yb >= ye and yb <= ye + alte:
                # Le pegó!!!!
                listaEnemigos.remove(enemigo)
                listaBalas.remove(bala)
                break

def verificarColisionIzquierda(listaEnemigosIzquierda, listaBalasIzquierda):
    for k in range (len(listaBalasIzquierda)-1,-1,-1):
        bala=listaBalasIzquierda[k]
        for e in range (len(listaEnemigosIzquierda)-1,-1,-1):  #Recorrer con Indices
            enemigo = listaEnemigosIzquierda[e]
            #bala VS enemigo
            xb = bala.rect.left
            yb = bala.rect.bottom
            xe, ye, ae, alte = enemigo.rect
            if xb >= xe and xb <= xe + ae and yb >= ye and yb <= ye + alte:
                # Le pegó!!!!
                listaEnemigosIzquierda.remove(enemigo)
                listaBalasIzquierda.remove(bala)
                break


def verificarColisionAbajo(listaEnemigosA, listaBalasAbajo):
    for k in range (len(listaBalasAbajo)-1,-1,-1):
        bala=listaBalasAbajo[k]
        for e in range (len(listaEnemigosA)-1,-1,-1):  #Recorrer con Indices
            enemigo = listaEnemigosA[e]
            #bala VS enemigo
            xb = bala.rect.left
            yb = bala.rect.bottom
            xe, ye, ae, alte = enemigo.rect
            if xb >= xe and xb <= xe + ae and yb >= ye and yb <= ye + alte:
                # Le pegó!!!!
                listaEnemigosA.remove(enemigo)
                listaBalasAbajo.remove(bala)
                break


def verificarColisionArriba(listaEnemigosArriba, listaBalasArriba):
    for k in range (len(listaBalasArriba)-1,-1,-1):
        bala=listaBalasArriba[k]
        for e in range (len(listaEnemigosArriba)-1,-1,-1):  #Recorrer con Indices
            enemigo = listaEnemigosArriba[e]
            #bala VS enemigo
            xb = bala.rect.left
            yb = bala.rect.bottom
            xe, ye, ae, alte = enemigo.rect
            if xb >= xe and xb <= xe + ae and yb >= ye and yb <= ye + alte:
                # Le pegó!!!!
                listaEnemigosArriba.remove(enemigo)
                listaBalasArriba.remove(bala)
                break


def dibujar():
    # Inicializa el motor de pygame
    pygame.init()
    # Crea una ventana de ANCHO x ALTO
    ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana donde dibujará
    reloj = pygame.time.Clock()  # Para limitar los fps
    termina = False  # Bandera para saber si termina la ejecución, iniciamos suponiendo que no

    #--------------------------------------------------------------------------------------------------------------------------------------------Personaje
    imgPersonaje = pygame.image.load("canon.png")
    spritePersonaje = pygame.sprite.Sprite()
    spritePersonaje.image = imgPersonaje
    spritePersonaje.rect= imgPersonaje.get_rect()
    spritePersonaje.rect.left = 360
    spritePersonaje.rect.bottom = ALTO//2 + spritePersonaje.rect.height//2

    #-----------------------------------------------------------------------------------------------------------------------------------------------Enemigos
    listaEnemigos = []
    imgEnemigo = pygame.image.load("enemigoNormal.png")
    """for k in range(5):
        spriteEnemigo = pygame.sprite.Sprite()
        spriteEnemigo.image = imgEnemigo
        spriteEnemigo.rect = imgEnemigo.get_rect()
        spriteEnemigo.rect.left = randint(800,2000)       #AREA DONDE SE GENERAN
        spriteEnemigo.rect.bottom = 350
        listaEnemigos.append(spriteEnemigo)"""


    listaEnemigosA = []
    """for k in range(5):
        spriteEnemigoA = pygame.sprite.Sprite()
        spriteEnemigoA.image = imgEnemigo
        spriteEnemigoA.rect = imgEnemigo.get_rect()
        spriteEnemigoA.rect.left = 350  # AREA DONDE SE GENERAN
        spriteEnemigoA.rect.bottom = randint(850,1000)
        listaEnemigosA.append(spriteEnemigoA)"""

    listaEnemigosArriba = []
    """for k in range(5):
        spriteEnemigoArriba = pygame.sprite.Sprite()
        spriteEnemigoArriba.image = imgEnemigo
        spriteEnemigoArriba.rect = imgEnemigo.get_rect()
        spriteEnemigoArriba.rect.left = 350  # AREA DONDE SE GENERAN
        spriteEnemigoArriba.rect.bottom = randint(-1000,0)
        listaEnemigosArriba.append(spriteEnemigoArriba)"""

    listaEnemigosIzquierda = []
    """for k in range(5):
        spriteEnemigoIzquierda = pygame.sprite.Sprite()
        spriteEnemigoIzquierda.image = imgEnemigo
        spriteEnemigoIzquierda.rect = imgEnemigo.get_rect()
        spriteEnemigoIzquierda.rect.left = randint(-1000,0)  # AREA DONDE SE GENERAN
        spriteEnemigoIzquierda.rect.bottom = 350
        listaEnemigosIzquierda.append(spriteEnemigoIzquierda)"""



    #-----------------------------------------------------------------------------------------------------------------------------------------------------Enemigos Norte+


    #---------------------------------------------------------------------------------------------------------------------------------------------------Proyectiles/balas
    listaBalas = []
    listaBalasIzquierda = []
    listaBalasAbajo = []
    listaBalasArriba = []
    imgBala = pygame.image.load("flame.png")

    #--------------------------------------------------------------------------------------------------------------------------------------------------Menú
    imgBtnJugar = pygame.image.load("button_iniciar-juego (3).png")
    imgFondo = pygame.image.load("back.jpg")
    imgFondoM = pygame.image.load("fondomenu.jpg")

    estado = MENU

    moviendo = QUIETO

    xf = 0

    #TIEMPO
    timer = 0   #Acumulador de tiempo

    #PUNTOS
    puntos = 0

    #TEXTO
    fuente = pygame.font.SysFont("monospace", 64)

    #AUDIO
    pygame.mixer.init()
    pygame.mixer.music.load("adamas-8bit.mp3")
    pygame.mixer.music.play(-1)     #-1 para infinito y 1 para momentaneo


    efecto = pygame.mixer.Sound("shoot.wav")


    while not termina:  # Ciclo principal, MIENTRAS la variable termina sea False, el ciclo se repite automáticamente
        # Procesa los eventos que recibe
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True      # Queremos terminar el ciclo
            elif evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_d:
                    #Crear una bala
                    efecto.play()
                    spriteBala = pygame.sprite.Sprite()
                    spriteBala.image = imgBala
                    spriteBala.rect = imgBala.get_rect()
                    spriteBala.rect.left = spritePersonaje.rect.left + spritePersonaje.rect.width
                    spriteBala.rect.bottom = spritePersonaje.rect.bottom
                    listaBalas.append(spriteBala)
            #elif evento.type == pygame.KEYDOWN:
                elif evento.key == pygame.K_a:
                    efecto.play()
                    spriteBalaIzquierda = pygame.sprite.Sprite()
                    spriteBalaIzquierda.image = imgBala
                    spriteBalaIzquierda.rect = imgBala.get_rect()
                    spriteBalaIzquierda.rect.left = spritePersonaje.rect.left - spritePersonaje.rect.width
                    spriteBalaIzquierda.rect.bottom = spritePersonaje.rect.bottom
                    listaBalasIzquierda.append(spriteBalaIzquierda)
                elif evento.key == pygame.K_x:
                    efecto.play()
                    spriteBalaAbajo = pygame.sprite.Sprite()
                    spriteBalaAbajo.image = imgBala
                    spriteBalaAbajo.rect = imgBala.get_rect()
                    spriteBalaAbajo.rect.left = spritePersonaje.rect.left
                    spriteBalaAbajo.rect.bottom = spritePersonaje.rect.bottom + spritePersonaje.rect.width
                    listaBalasAbajo.append(spriteBalaAbajo)
                elif evento.key == pygame.K_w:
                    efecto.play()
                    spriteBalaArriba = pygame.sprite.Sprite()
                    spriteBalaArriba.image = imgBala
                    spriteBalaArriba.rect = imgBala.get_rect()
                    spriteBalaArriba.rect.left = spritePersonaje.rect.left
                    spriteBalaArriba.rect.bottom = spritePersonaje.rect.bottom - spritePersonaje.rect.width
                    listaBalasArriba.append(spriteBalaArriba)


            elif evento.type == pygame.MOUSEBUTTONUP:
                xm, ym = pygame.mouse.get_pos()
                print(xm,",",ym)
                #Preguntar si soltó el mouse dentro del botón
                xb = ANCHO//2-128
                yb= ALTO//3
                if xm >= yb and xm <= yb + 256 and ym >= yb and ym <= yb+100:
                    estado = JUGANDO



        # Borrar pantalla
        ventana.fill(NEGRO)

        if estado == JUGANDO:

            #TIEMPO
            if timer >= 2:  #>Tiene que llegar a 2
                timer = 0   #Vuelve a ser cero
            #Actualizar enemigos
            # Mover PERSONAJE
                # Crear una bala
                #efecto.play()--------------------------------------------------------------------------- CREA BALA AUTOMATICA
                #spriteBala = pygame.sprite.Sprite()
                #spriteBala.image = imgBala
                #spriteBala.rect = imgBala.get_rect()
                #spriteBala.rect.left = spritePersonaje.rect.left + spritePersonaje.rect.width
                #spriteBala.rect.bottom = spritePersonaje.rect.bottom
                #listaBalas.append(spriteBala)

                #----------------------------------------------------------------------------------------- CREA ENEMIGO DESPUÉS DE PANATALLA
                spriteEnemigo = pygame.sprite.Sprite()
                spriteEnemigo.image = imgEnemigo
                spriteEnemigo.rect = imgEnemigo.get_rect()
                spriteEnemigo.rect.left = randint(800,2000)  # AREA DONDE SE GENERAN
                spriteEnemigo.rect.bottom = 350
                listaEnemigos.append(spriteEnemigo)

                spriteEnemigoIzquierda = pygame.sprite.Sprite()
                spriteEnemigoIzquierda.image = imgEnemigo
                spriteEnemigoIzquierda.rect = imgEnemigo.get_rect()
                spriteEnemigoIzquierda.rect.left = randint(-1000,0) # AREA DONDE SE GENERAN
                spriteEnemigoIzquierda.rect.bottom = 350
                listaEnemigosIzquierda.append(spriteEnemigoIzquierda)

                spriteEnemigoA = pygame.sprite.Sprite()
                spriteEnemigoA.image = imgEnemigo
                spriteEnemigoA.rect = imgEnemigo.get_rect()
                spriteEnemigoA.rect.left = 350  # AREA DONDE SE GENERAN
                spriteEnemigoA.rect.bottom = randint(850, 1000)
                listaEnemigosA.append(spriteEnemigoA)

                spriteEnemigoArriba = pygame.sprite.Sprite()
                spriteEnemigoArriba.image = imgEnemigo
                spriteEnemigoArriba.rect = imgEnemigo.get_rect()
                spriteEnemigoArriba.rect.left = 350  # AREA DONDE SE GENERAN
                spriteEnemigoArriba.rect.bottom = randint (-1000, 0)
                listaEnemigosArriba.append(spriteEnemigoArriba)

            if moviendo == ARRIBA:
                spritePersonaje.rect.bottom -= 1
            elif moviendo == ABAJO:
                spritePersonaje.rect.bottom += 1


            # Dibujar, aquí haces todos los trazos que requieras
            ventana.blit(imgFondo, (xf,0))
            #xf -= 1         Avanza pantalla
            #---------------------------------------------PERSONAJE-------------------------------------
            dibujarPersonaje(ventana, spritePersonaje)
            #---------------------------------------------ENEMIGOS--------------------------------------
            dibujarEnemigos(ventana, listaEnemigos)
            dibujarEnemigosA(ventana, listaEnemigosA)
            dibujarEnemigosArriba(ventana, listaEnemigosArriba)
            dibujarEnemigosIzquierda(ventana, listaEnemigosIzquierda)
            moverEnemigos(listaEnemigos)
            moverEnemigosA(listaEnemigosA)
            moverEnemigosIzquierda(listaEnemigosIzquierda)
            moverEnemigosArriba(listaEnemigosArriba)
            #----------------------------------------------BALAS-----------------------------------------
            moverBalas(listaBalas)
            moverBalasIzquierda(listaBalasIzquierda)
            moverBalasAbajo(listaBalasAbajo)
            moverBalasArriba(listaBalasArriba)
            dibujarBalas(ventana, listaBalas)
            dibujarBalasIzquierda(ventana, listaBalasIzquierda)
            dibujarBalasAbajo(ventana, listaBalasAbajo)
            dibujarBalasArriba(ventana, listaBalasArriba)
            verificarColision(listaEnemigos, listaBalas)
            puntos += 1
            verificarColisionIzquierda(listaEnemigosIzquierda, listaBalasIzquierda)
            verificarColisionAbajo(listaEnemigosA, listaBalasAbajo)
            verificarColisionArriba(listaEnemigosArriba, listaBalasArriba)

        elif estado == MENU:

            #Dibujar menú
            ventana.blit(imgFondoM, (xf, 0))
            dibujarMenu(ventana, imgBtnJugar)

            # Texto en la pantalla
            titulo = fuente.render("SURVIVAL CANON", 1, VERDE)
            ventana.blit(titulo,(100, ALTO//2 +100))
        texto = fuente.render("PUNTOS %d" % puntos, 1, ROJO)
        ventana.blit(texto, (ANCHO // 2 - 400, 0))



        pygame.display.flip()  # Actualiza trazos (Si no llamas a esta función, no se dibuja)
        reloj.tick(40)  # 40 fps
        timer += 1/20

    # Después del ciclo principal
    pygame.quit()  # termina pygame


# Función principal, aquí resuelves el problema
def main():
    dibujar()   # Por ahora, solo dibuja


# Llamas a la función principal
main()