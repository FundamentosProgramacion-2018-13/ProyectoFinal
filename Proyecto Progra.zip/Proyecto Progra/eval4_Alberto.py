#Alberto Contreras Torres
#4ta evaluación

#Crea un abecedario y verifica que cada una de las palabras corresponda a su numero
def asignarValores(abecedario):
    n = abecedario.upper()

    letras = list(n)

    letras.sort()
    valores = {}

    contador = 1
    for x in letras:
        valores[x] = contador
        contador += 1

    return valores


def sumaPalabra1(a):
    palabra1 =  a["K"] + a["N"] + a["O"] + a["W"] + a["L"] + a["E"] + a["D"] + a["G"] + a["E"]
    return palabra1


def sumaPalabra2(a):
    palabra2 = a["H"] + a["A"] + a["R"] + a["D"] + a["W"] + a["O"] + a["R"] + a["K"]
    return palabra2


def sumaPalabra3(a):
    palabra3 = a["A"] + a["T"] + a["T"] + a["I"] + a["T"] + a["U"] + a["D"] + a["E"]
    return palabra3

#recibe mi nombre como cadena, la convierte a lista y lee sus valores en el diccionario
def sumaNombre(a):

    cadena = "ALBERTOCONTRERASTORRES"
    letras = list(cadena)

    suma = 0
    for x in letras:
        valorLetra = a[x]
        suma += valorLetra

    return suma


#Divide en caracteres las palabras del archivo, regresa su sumatoria
def sumaPalabras(a):
    entrada = open("palabras.txt", "r", encoding = "UTF-8")

    salida = open("suma.txt", "w")

    suma = 0
    for linea in entrada:
        cadena = list(linea.upper().rstrip('/n'))

        for caracter in cadena:
            valorLetra = a[caracter]
            suma += valorLetra


        salida.write(linea, suma)
    entrada.close()


#Leé las lineas de el poema y extra las primeras, letras para formar una cadena
def formarCadena(archivo):
    entrada = open(archivo, "r", encoding = "UTF-8")
    cadena = ""
    for linea in entrada:
        cadena += linea[0]
        cadena = cadena.rstrip("\n")
        cadena = cadena.upper()

    posiciones = 0
    cadena2 = ""
    for letras in cadena:
        cadena2 += letras
        posiciones += 1

        if posiciones == 11:
            cadena2 += " "
        elif posiciones == 13:
            cadena2 += " "
    entrada.close()
    print (cadena2)


def main():
    print("----------------------------PROBLEMA 1 --------------------------------------")
    abecedario= "abcdefghijklmnopqrstuvwxyz"
    a = asignarValores(abecedario)
    print(a)
    b = sumaPalabra1(a)
    print("K+N+W+O+L+E+D+G+E =",b)
    c = sumaPalabra2(a)
    print("H+A+R+D+W+O+R+K =",c)
    d = sumaPalabra3(a)
    print("A+T+T+I+T+U+D+E =",d)
    print("----------------------------PROBLEMA 2 --------------------------------------")
    e = sumaNombre(a)
    print("Mi nombre: Alberto Contreras Torres, suma:",e)
    print("----------------------------PROBLEMA 3 --------------------------------------")
    #f= sumaPalabras(a)
    #print(f)
    print("----------------------------PROBLEMA 4 --------------------------------------")
    formarCadena("poema.txt")

main()