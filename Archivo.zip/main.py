import pygame
from timeit import default_timer as timer

pygame.init()
pygame.mixer.init()

# Ventana
Largo = 800
Alto = 600
ventana = pygame.display.set_mode([Largo, Alto])

# Archivo Highscore
archivo = open("tiempos.txt", "r+")
record = float(archivo.readlines()[len(archivo.readlines())-1])

# Texto
pygame.font.init()
texto = pygame.font.SysFont('Arial', 40, True)

# Colores
NEGRO = (0, 0, 0)
BLANCO = (255, 255, 255)
ROJO = (255, 0, 0)
AZUL = (0, 0, 255)
VERDE = (0, 255, 0)

# Fondos
fondoPerdiste = pygame.image.load("FondoPerdiste.jpg")
fondoMenu = pygame.image.load("FondoMenu.png")
fondoE1 = pygame.image.load("FondoE1.png")
fondoE2 = pygame.image.load("FondoE2.png")
fondoE3 = pygame.image.load("FondoE3.png")
fondoGanaste = pygame.image.load("Ganado.png")

# Personas ( Deben ser de 50 x 200 )
imgPolicia = pygame.image.load("imgPolicia.png")
imgPersona1 = pygame.image.load("fantasma.png")
imgPersona2 = pygame.image.load("imgPersona2.png")

# Botones  ( Deben ser de 50 x 20 )
boton1 = pygame.image.load("boton1.png")
boton2 = pygame.image.load("boton2.png")
boton3 = pygame.image.load("boton3.png")

# Notas  ( Deben ser de 700 x 580 )
nota1 = pygame.image.load("nota1.png")
nota2 = pygame.image.load("Mapa.png")
nota3 = pygame.image.load("nota3.png")

# Sonidos
pygame.mixer.music.load("noche.mp3")
pygame.mixer.music.play(-1)
pasos = pygame.mixer.Sound("pasos.ogg")
daño = pygame.mixer.Sound("daño.ogg")

# Variables globales
Escenario = 0

# Listas
Obstaculos = []
Botones = []
BotonNotas = []
Notas = []

# Para personajes que se mueven, la estructura del tuple será:
# nombreObjeto = (img, x, y, velocidad, activo, vida)
policia = (imgPolicia, 20, 350, 5, True, 100)

# Para personajes u objetos estáticos, la estructura del tuple será:
# nombreObjeto = (img, x, y, activo)
persona = (imgPersona1, 200, 350, True)


def mostrarNota(notaAMostrar):
    Notas.append((notaAMostrar, (50, 10)))
    BotonNotas.append((boton2, (700, 20)))


def dibujarNota():
    for nota in Notas:
        img, pos = nota
        ventana.blit(img, pos)
    for boton in BotonNotas:
        img, pos = boton
        ventana.blit(img, pos)


def crearBoton(img, x, y, fun):
    Botones.append((img, (x, y), fun))


def dibujarBotones():
    for boton in Botones:
        img, pos, fun = boton
        ventana.blit(img, pos)


def llamarFuncion(funcion):
    if funcion == 0:
        global Escenario, policia
        imgPolicia, x, y, velocidad, activo, vida = policia
        Botones.clear()
        Obstaculos.clear()
        Escenario = 1
        Escenarios(Escenario)
        policia = (imgPolicia, 20, y, velocidad, activo, vida)

    if funcion == 1:
        global persona
        persona = (imgPersona1, 200, 350, False)

    if funcion == 2:
        mostrarNota(nota1)

    if funcion == 3:
        mostrarNota(nota2)

    if funcion == -3:
        Notas.clear()
        BotonNotas.clear()
        Escenarios(Escenario)


def dibujarMovil(movil):
    img, x, y, v, activo, vida = movil
    if activo:
        ventana.blit(img, (x, y))


def dibujarObstaculos():
    for obst in Obstaculos:
        img, x, y, activo = obst
        if activo:
            ventana.blit(img, (x, y))


def atacarPolicia(ataque):
    global policia, run, Escenario
    img, x, y, v, activo, vida = policia
    vida -= ataque
    if vida <= 0:
        Escenario = 9
    policia = (img, x, y, v, activo, vida)


def moverPolicia():
    global policia
    img, x, y, v, activo, vida = policia
    libre = True
    for obstaculo in Obstaculos:
        imgo, xo, yo, activoo = obstaculo
        if (xo < x + v < xo + 50 or xo < x + 50 + v < xo + 50) and activoo:

            atacarPolicia(2)
            libre = False
            break

    if 0 < x + v < Largo and libre:
        x += v
        policia = (img, x, y, v, activo, vida)


def dibujarVida():
    global policia
    img, x, y, v, activo, vida = policia
    pygame.draw.rect(ventana, ROJO, (20, 20, int(vida * 2), 20))


def Escenarios(escenario):
    if escenario == 9:
        Botones.clear()

    if escenario == 0:
        Botones.clear()
        Obstaculos.clear()
        crearBoton(boton1, 400, 200, 0)
        crearBoton(boton2, 400, 400, 1)

    if escenario == 1:
        Botones.clear()
        Obstaculos.clear()
        Notas.clear()
        BotonNotas.clear()
        crearBoton(boton3, 400, 400, 2)
        crearBoton(boton3, 720, 20, 3)
        Obstaculos.append(persona)

    if escenario == 2:
        Botones.clear()
        Obstaculos.clear()
        Notas.clear()
        BotonNotas.clear()

        crearBoton(boton3, 720, 20, 3)

    if escenario == 3:
        global record, timerInicio
        if record > timerInicio:
            archivo.write("\n" + str(timerInicio + 10))
        Botones.clear()
        Obstaculos.clear()
        Notas.clear()
        BotonNotas.clear()

        crearBoton(boton3, 720, 20, 3)

    if escenario == 4:
        Botones.clear()


def Dibujar():
    global Escenario

    if Escenario == 9:
        ventana.blit(fondoPerdiste, (0,0))

    if Escenario == 0:
        ventana.blit(fondoMenu, (0, 0))
        dibujarBotones()

    if Escenario == 1:
        ventana.blit(fondoE1, (0, 0))
        dibujarBotones()
        dibujarObstaculos()
        dibujarMovil(policia)
        dibujarVida()
        dibujarNota()

    if Escenario == 2:
        ventana.blit(fondoE2, (0, 0))
        dibujarBotones()
        dibujarObstaculos()
        dibujarMovil(policia)
        dibujarVida()
        dibujarNota()

    if Escenario == 3:
        ventana.blit(fondoGanaste, (0, 0))






    pygame.display.update()




run = True

reloj = pygame.time.Clock()

Escenarios(0)
timerInicio = timer()

while run:
    reloj.tick(24)

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            run = False

        if evento.type == pygame.MOUSEBUTTONUP:
            pos = pygame.mouse.get_pos()
            for boton in Botones:
                img, posb, fun = boton
                x, y = posb
                if x - 50 < pos[0] < x + 50 and y - 20 < pos[1] < y + 20:
                    llamarFuncion(fun)
            for boton in BotonNotas:
                img, posb = boton
                x, y = posb
                if x < pos[0] < x + 50 and y < pos[1] < y + 20:
                    llamarFuncion(-3)

    keys = pygame.key.get_pressed()

    if (keys[pygame.K_LEFT] or keys[pygame.K_RIGHT]) and Escenario != 0:
        if keys[pygame.K_LEFT]:
            img, x, y, velocidad, activo, vida = policia
            pasos.play()
            policia = img, x, y, -10, activo, vida
        if keys[pygame.K_RIGHT]:
            img, x, y, velocidad, activo, vida = policia
            pasos.play()
            policia = img, x, y, 10, activo, vida

    elif (keys[pygame.K_LEFT] and keys[pygame.K_RIGHT]) and Escenario != 0:
        img, x, y, velocidad, activo, vida = policia
        pasos.stop()
        policia = (img, x, y, 0, activo, vida)

    elif (not keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT]) and Escenario != 0:
        img, x, y, velocidad, activo, vida = policia
        pasos.stop()
        policia = (img, x, y, 0, activo, vida)

    if Escenario != 0:
        moverPolicia()
        img, x, y, velocidad, activo, vida = policia
        if x > Largo - 20 and Escenario < 3:
            Escenario += 1
            policia = (imgPolicia, 20, y, velocidad, activo, vida)
            Escenarios(Escenario)
        if x < 15:
            Escenario -= 1
            policia = (imgPolicia, 750, y, velocidad, activo, vida)
            Escenarios(Escenario)





    Dibujar()

archivo.close()
pygame.quit()
