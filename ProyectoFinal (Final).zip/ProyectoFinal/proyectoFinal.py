# Danhel Alejandro
# juego con pygame
# Proyecto final

import pygame
from random import randint
import math

# Dimensiones de la pantalla
ANCHO = 640
ALTO = 480
# # Colores
BLANCO = (255, 255, 255)  # R,G,B en el rango [0,255], 0 ausencia de color, 255 toda la intensidad
VERDE_BANDERA = (27, 94, 32)    # un poco de rojo, más de verde, un poco de azul
ROJO = (255, 0, 0)      # solo rojo, nada de verde, nada de azul
AZUL = (0, 0, 255)      # nada de rojo, ni verde, solo azul
NEGRO = (0, 0, 0)

#Estado
MENU = 1
JUGANDO = 2
NIVEL2 = 3
GANAR = 5
PERDER = 4
PUNTOS = 0

# Estructura básica de un programa que usa pygame para dibujar

validChars = "1234567890-=qwertyuiop[]\\asdfghjkl;'zxcvbnm"
shiftChars = '~!@#$%^&*()_+QWERTYUIOP{}ASDFGHJKL:"ZXCVBNM<>?'

def dibujarPuntos(ventana, spritePuntos, PUNTOS):

    fuente = pygame.font.SysFont("Upheaval TT (BRK)", 60)
    puntos = fuente.render(str(PUNTOS), False, (225, 225, 255))
    ventana.blit(puntos, (50,50))

def add_chr(spritePuntos, char):
    shiftDown = False
    if char in validChars and not shiftDown:
        spritePuntos.text += char
    elif char in validChars and shiftDown:
        spritePuntos.text += shiftChars[validChars.index(char)]
        update(spritePuntos)

def update(spritePuntos):
    old_rect_pos = spritePuntos.rect.center
    spritePuntos.image = spritePuntos.font.render(spritePuntos.text, False, [225, 225, 225])
    spritePuntos.rect = spritePuntos.image.get_rect()
    spritePuntos.rect.center = old_rect_pos

def update1(spritePuntos, PUNTOS):
    spritePuntos.text = str(PUNTOS)
    old_rect_pos = spritePuntos.rect.center
    spritePuntos.image = spritePuntos.font.render(spritePuntos.text, False, [225, 225, 225])
    spritePuntos.rect = spritePuntos.image.get_rect()
    spritePuntos.rect.center = old_rect_pos



def dibujarPersonaje(ventana, spritePersonaje):
    ventana.blit(spritePersonaje.image, spritePersonaje.rect)

def dibujarEnemigos(ventana, listaEnemigos):
    for enemigo in listaEnemigos:
        ventana.blit(enemigo.image, enemigo.rect)

def moverEnemigos(listaEnemigos, alfa):
    for enemigos in listaEnemigos:
        if enemigos.rect.bottom <= ALTO/2:
            enemigos.rect.bottom += 1
            dx = 2*math.cos(math.radians(alfa))
            enemigos.rect.left += dx



def dibujarBalas(ventana, listaBalas):
    for bala in listaBalas:
        if bala.rect.bottom <= 0:
            listaBalas.remove(bala)


    for bala in listaBalas:
        ventana.blit(bala.image, bala.rect)



def moverBalas(listaBalas):
    for bala in listaBalas:
        bala.rect.bottom -= 20



def dibujarMenu(ventana, imgBtnJugar):
    ventana.blit(imgBtnJugar, (ANCHO//2-128, ALTO//3))



def verificarColision(listaEnemigos, listaBalas, spritePuntos):
    global PUNTOS

    for bala in listaBalas:
        for enemigo in listaEnemigos:   #Recorrer con INDICES
            #bala vs enemigo
            xb = bala.rect.left
            yb = bala.rect.bottom
            xe = enemigo.rect.left
            ye = enemigo.rect.bottom
            anchoE = enemigo.rect.width
            anchoB = bala.rect.width
            altoB= bala.rect.height
            altoE = enemigo.rect.height
            if (xe<=xb+10<=xe+anchoE or xe<=xb+anchoB-10<=xe+anchoE) and ye<=yb<= ye+altoE:
                #Golpeo al enemigo
                listaEnemigos.remove(enemigo)
                listaBalas.remove(bala)
                PUNTOS = PUNTOS + 1
                update1(spritePuntos, PUNTOS)
                break

def dibujar():
    # Inicializa el motor de pygame
    pygame.init()
    # Crea una ventana de ANCHO x ALTO
    ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana donde dibujará
    reloj = pygame.time.Clock()  # Para limitar los fps
    termina = False  # Bandera para saber si termina la ejecución, iniciamos suponiendo que no

    imgPersonaje = pygame.image.load("pytanque1.png")
    spritePersonaje = pygame.sprite.Sprite()
    spritePersonaje.image = imgPersonaje
    spritePersonaje.rect = imgPersonaje.get_rect()
    spritePersonaje.rect.left = ANCHO//2
    spritePersonaje.rect.bottom = ALTO

    imgPersonaje2 = pygame.image.load("pytanque2.png")
    spritePersonaje2 = pygame.sprite.Sprite()
    spritePersonaje2.image = imgPersonaje2
    spritePersonaje2.rect = imgPersonaje2.get_rect()
    spritePersonaje2.rect.left = ANCHO // 2
    spritePersonaje2.rect.bottom = ALTO

    imgPuntos = pygame.image.load("button.png")
    spritePuntos = pygame.sprite.Sprite()
    spritePuntos.image = imgPuntos
    spritePuntos.rect = imgPersonaje.get_rect()
    spritePuntos.rect.left = 60
    spritePuntos.rect.bottom = 60

    spritePuntos.text = ""
    spritePuntos.font = pygame.font.SysFont("Upheaval TT (BRK)", 60)
    spritePuntos.image = spritePuntos.font.render("puntos acomulados =", False, (225, 225, 255))
    spritePuntos.rect = spritePuntos.image.get_rect()


    listaEnemigos = []
    imgEnemigo = pygame.image.load("pynave1.png")
    for k in range(50):
        spriteEnemigo = pygame.sprite.Sprite()
        spriteEnemigo.image = imgEnemigo
        spriteEnemigo.rect = imgEnemigo.get_rect()
        spriteEnemigo.rect.left = randint(0, ANCHO-spriteEnemigo.rect.width) + ANCHO
        #spriteEnemigo.rect.bottom = randint(0,ANCHO)
        listaEnemigos.append(spriteEnemigo)

    listaEnemigos2 = []
    imgEnemigo2 = pygame.image.load("pynave2.png")
    for k in range(50):
        spriteEnemigo = pygame.sprite.Sprite()
        spriteEnemigo.image = imgEnemigo2
        spriteEnemigo.rect = imgEnemigo2.get_rect()
        spriteEnemigo.rect.left = randint(0, ANCHO-spriteEnemigo.rect.width) + ANCHO
        #spriteEnemigo.rect.bottom = randint(0,ANCHO)
        listaEnemigos2.append(spriteEnemigo)

    listaBalas = []
    imgBala = pygame.image.load("pybala1.png")

    listaBalas2 = []
    imgBala2 = pygame.image.load("pybala2.png")

    estado = MENU



    #Menú

    imgBtnJugar = pygame.image.load("button_jugar.png")



    #Fondo
    imgFondo = pygame.image.load("tierra.jpg")

    imgFondo2 = pygame.image.load("luna.jpg")

    imgTierra = pygame.image.load("tierra.jpg")




    # Tiempo
    timer = 0 # Acumulador de tiempo

    # Texto
    fuente = pygame.font.SysFont("monospace", 64)

    # Audio
    pygame.mixer.init()
    pygame.mixer.music.load("musicaFondo.mp3")
    pygame.mixer.music.play(-1)
    efecto = pygame.mixer.Sound("shoot.wav")

    angulo = 0

    while not termina:  # Ciclo principal, MIENTRAS la variable termina sea False, el ciclo se repite automáticamente
        # Procesa los eventos que recibe
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True      # Queremos terminar el ciclo
            elif evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_RIGHT:
                    if estado == JUGANDO:
                        spritePersonaje.rect.left += 30
                    if estado == NIVEL2:
                        spritePersonaje2.rect.left += 30
                elif evento.key == pygame.K_LEFT:
                    if estado == JUGANDO:
                        spritePersonaje.rect.left -= 30
                    if estado == NIVEL2:
                        spritePersonaje2.rect.left -= 30
                elif evento.key == pygame.K_z:
                    if estado == JUGANDO:
                        spriteBala = pygame.sprite.Sprite()
                        spriteBala.image = imgBala
                        spriteBala.rect = imgBala.get_rect()
                        spriteBala.rect.left = spritePersonaje.rect.left + spritePersonaje.rect.width//2-spriteBala.rect.width//2
                        spriteBala.rect.bottom = spritePersonaje.rect.bottom-spritePersonaje.rect.width
                        listaBalas.append(spriteBala)
                    if estado == NIVEL2:
                        spriteBala = pygame.sprite.Sprite()
                        spriteBala.image = imgBala
                        spriteBala.rect = imgBala.get_rect()
                        spriteBala.rect.left = spritePersonaje2.rect.left + spritePersonaje2.rect.width // 2 - spriteBala.rect.width // 2
                        spriteBala.rect.bottom = spritePersonaje2.rect.bottom - spritePersonaje2.rect.width
                        listaBalas.append(spriteBala)


            elif evento.type == pygame.MOUSEBUTTONUP:
                xm, ym = pygame.mouse.get_pos() #valores de dubla
                print(xm, ", ", ym)
                xb = ANCHO//2-128
                yb = ALTO//3
                if xm > xb and xm <= xb + 256 and ym >= yb and ym <= yb + 100:
                    estado = JUGANDO







        # Borrar pantalla
        ventana.fill(NEGRO)

        if estado == JUGANDO:
            #Tiempo
            if timer >= 2:
                timer = 0
                # Crear una bala
                #efecto.play()

                # ENEMIGOS
                spriteEnemigo = pygame.sprite.Sprite()
                spriteEnemigo.image = imgEnemigo
                spriteEnemigo.rect = imgEnemigo.get_rect()
                spriteEnemigo.rect.left = randint(0, ANCHO)
                spriteEnemigo.rect.bottom = randint(0, ALTO//2)-ALTO//2
                listaEnemigos.append(spriteEnemigo)

            #Actualizar enemigos
            moverEnemigos(listaEnemigos, angulo)
            angulo = (angulo + 1) % 360
            moverBalas(listaBalas)
            verificarColision(listaEnemigos, listaBalas, spritePuntos)


            # Dibujar, aquí haces todos los trazos que requieras
            # Normalmente llamas a otra función y le pasas -ventana- como parámetro, por ejemplo, dibujarLineas(ventana)
            # Consulta https://www.pygame.org/docs/ref/draw.html para ver lo que puede hacer draw
            ventana.blit(imgFondo, (0, 0))
            dibujarPersonaje(ventana, spritePersonaje)
            dibujarEnemigos(ventana, listaEnemigos)
            dibujarBalas(ventana, listaBalas)
            dibujarPuntos(ventana, spritePuntos, PUNTOS)
            #ventana.blit(spritePuntos.image, spritePuntos.rect)



            if PUNTOS > 2:
                estado = NIVEL2






        elif estado == NIVEL2:
            angulo = 0
            # ENEMIGOS
            spriteEnemigo2 = pygame.sprite.Sprite()
            spriteEnemigo2.image = imgEnemigo2
            spriteEnemigo2.rect = imgEnemigo2.get_rect()
            spriteEnemigo2.rect.left = randint(0, ANCHO)
            spriteEnemigo2.rect.bottom = randint(0, ALTO // 2) - ALTO // 2
            listaEnemigos2.append(spriteEnemigo2)

            # Actualizar enemigos
            moverEnemigos(listaEnemigos2, angulo)
            angulo = (angulo + 1) % 360
            moverBalas(listaBalas)
            verificarColision(listaEnemigos2, listaBalas, spritePuntos)


            ventana.blit(imgFondo2, (0, 0))
            dibujarPersonaje(ventana, spritePersonaje2)
            dibujarEnemigos(ventana, listaEnemigos2)
            dibujarBalas(ventana, listaBalas)
            dibujarPuntos(ventana, spritePuntos, PUNTOS)
            if PUNTOS >6:
                estado = GANAR


        elif estado == GANAR:
            ventana.blit(imgFondo2, (0, 0))
            fuente = pygame.font.Font(None, 60)
            textoPuntaje = fuente.render(("GANASTE!"), 0, (255, 255, 255))
            ventana.blit(textoPuntaje, (ANCHO//2-100, ALTO//2-30))

        elif estado == MENU:
            #Dinujar menú
            dibujarMenu(ventana, imgBtnJugar)

            #Texto de la pantalla
            #texto = fuente.render("Valor de imgFondo %d" % imgFondo, 1, ROJO)
            #ventana.blit(texto, (ANCHO // 2 - 400, 50))

        #elif estado == GANADOR:
            #if puntos =

        pygame.display.flip()  # Actualiza trazos (Si no llamas a esta función, no se dibuja)
        reloj.tick(40)  # 40 fps
        timer += 1/40

    # Después del ciclo principal
    pygame.quit()  # termina pygame


# Función principal, aquí resuelves el problema
def main():
    dibujar()   # Por ahora, solo dibuja








# Llamas a la función principal
main()